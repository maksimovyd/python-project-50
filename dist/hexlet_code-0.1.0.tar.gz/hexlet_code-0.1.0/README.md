### Hexlet tests and linter status:
[![Actions Status](https://github.com/maksimovyd/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/maksimovyd/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e1d6b5a111c187eecb16/maintainability)](https://codeclimate.com/github/maksimovyd/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/e1d6b5a111c187eecb16/test_coverage)](https://codeclimate.com/github/maksimovyd/python-project-50/test_coverage)

[![asciicast](https://asciinema.org/a/SLLb57wWooOZSYDp6vpgikCor.svg)](https://asciinema.org/a/SLLb57wWooOZSYDp6vpgikCor)
[![asciicast](https://asciinema.org/a/jSiVpIu5jzTHZiJIopVaAqjsU.svg)](https://asciinema.org/a/jSiVpIu5jzTHZiJIopVaAqjsU)
[![asciicast](https://asciinema.org/a/NHTUV6jAyNq7WGRCQ2HGZbRSc.svg)](https://asciinema.org/a/NHTUV6jAyNq7WGRCQ2HGZbRSc)
[![asciicast](https://asciinema.org/a/zpSw9p4HxHEUkhZ63SQPjmCrI.svg)](https://asciinema.org/a/zpSw9p4HxHEUkhZ63SQPjmCrI)
[![asciicast](https://asciinema.org/a/71mIKMAbCIbmyURUBT9IC7qk0.svg)](https://asciinema.org/a/71mIKMAbCIbmyURUBT9IC7qk0)
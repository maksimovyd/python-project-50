### Hexlet tests and linter status:
[![Actions Status](https://github.com/maksimovyd/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/maksimovyd/python-project-50/actions)

[asciinema rec 1](https://asciinema.org/connect/9b027ca2-4739-4824-89d1-6f1d14d775b4)

![GitHub 
Actions](https://github.com/maksimovyd/python-project-50/workflows/hexlet-check/badge.svg)

[![Maintainability](https://api.codeclimate.com/v1/badges/650500538fe6011d137b5715/maintainability)](https://codeclimate.com/github/ваш-логин/ваш-репозиторий/maintainability)


### Hexlet tests and linter status:
[![Actions Status](https://github.com/maksimovyd/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/maksimovyd/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e1d6b5a111c187eecb16/maintainability)](https://codeclimate.com/github/maksimovyd/python-project-50/maintainability)
[![Test 
Coverage](https://api.codeclimate.com/v1/badges/e1d6b5a111c187eecb16/test_coverage)](https://codeclimate.com/github/maksimovyd/python-project-50/test_coverage)

[asciinema rec 1](https://asciinema.org/connect/9b027ca2-4739-4824-89d1-6f1d14d775b4)
